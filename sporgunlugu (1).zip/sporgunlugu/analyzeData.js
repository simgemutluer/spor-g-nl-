// analyzeData.js

export const analyzeBeslenme = (data) => {
  if (data.length === 0) {
    return "Beslenme verisi bulunmuyor.";
  }

  // Örnek analiz: Toplam kalori hesaplama
  const totalCalories = data.reduce((total, item) => total + parseFloat(item.kaloriler) || 0, 0);

  return `Toplam kalori: ${totalCalories.toFixed(2)}`;
};

export const analyzeEgzersiz = (data) => {
  if (data.length === 0) {
    return "Egzersiz verisi bulunmuyor.";
  }

  // Örnek analiz: Toplam harcanan kalori hesaplama
  const totalBurnedCalories = data.reduce((total, item) => total + parseFloat(item.harcananKaloriler) || 0, 0);

  return `Toplam harcanan kalori: ${totalBurnedCalories.toFixed(2)}`;
};

export const analyzeSporlar = (data) => {
  if (data.length === 0) {
    return "Spor aktivitesi verisi bulunmuyor.";
  }

  // Örnek analiz: Hangi spor aktivitesi daha sık yapılmış
  const sportsCount = data.reduce((count, item) => {
    const sport = item.spor.toLowerCase();
    count[sport] = (count[sport] || 0) + 1;
    return count;
  }, {});

  const mostPracticedSport = Object.keys(sportsCount).reduce((a, b) => sportsCount[a] > sportsCount[b] ? a : b);

  return `En çok yapılan spor aktivitesi: ${mostPracticedSport}`;
};

export const analyzeUyku = (data) => {
  if (data.length === 0) {
    return "Uyku verisi bulunmuyor.";
  }

  // Örnek analiz: Ortalama uyku süresi hesaplama
  const averageSleepDuration = data.reduce((total, item) => total + parseFloat(item.uykuSuresi) || 0, 0) / data.length;

  return `Ortalama uyku süresi: ${averageSleepDuration.toFixed(2)} saat`;
};


export default App;




