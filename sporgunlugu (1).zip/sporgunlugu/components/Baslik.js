import {StyleSheet, Text} from "react-native"

const Baslik = () => {
  return(
    <Text style={styles.title}>Spor Günlüğü</Text>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
  },
  input: {
    width: 300,
    height: 40,
    borderColor: "black",
    borderWidth: 1,
    borderRadius: 5,
  },
  button: {
    width: 100,
    height: 40,
    backgroundColor: "green",
    color: "white",
    borderRadius: 5,
  },
});

export default Baslik 