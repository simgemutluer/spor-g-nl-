// App.js

import React, { useState } from "react";
import { SafeAreaView, StyleSheet, Text, TextInput, Button, ScrollView } from "react-native";
import Baslik from "./components/Baslik";
import { analyzeBeslenme, analyzeEgzersiz, analyzeSporlar, analyzeUyku } from "./components/analyzeData";

const App = () => {
  const [beslenme, setBeslenme] = useState("");
  const [egzersizler, setEgzersiz] = useState("");
  const [sporlar, setSporlar] = useState("");
  const [uyumalar, setUykular] = useState("");
  const [data, setData] = useState([]);
  const [analizSonucu, setAnalizSonucu] = useState("");

  const handleBeslenmeEkle = () => {
    const newRecordBeslenme = {
      category: "beslenme",
      kaloriler: beslenme,
      zaman: new Date().toLocaleDateString(),
    };
    setData([...data, newRecordBeslenme]);
    setBeslenme("");
  };

  const handleEgzersizEkle = () => {
    const newRecordEgzersiz = {
      category: "egzersiz",
      harcananKaloriler: egzersizler,
      zaman: new Date().toLocaleDateString(),
    };
    setData([...data, newRecordEgzersiz]);
    setEgzersiz("");
  };

  const handleSporEkle = () => {
    const newRecordSpor = {
      category: "sporlar",
      spor: sporlar,
      zaman: new Date().toLocaleDateString(),
    };
    setData([...data, newRecordSpor]);
    setSporlar("");
  };

  const handleUykuEkle = () => {
    const newRecordUyku = {
      category: "uyku",
      uykuSuresi: uyumalar,
      zaman: new Date().toLocaleDateString(),
    };
    setData([...data, newRecordUyku]);
    setUykular("");
  };

  const handleAnalizEkle = (category) => {
    let result = "";

    switch (category) {
      case "beslenme":
        result = analyzeBeslenme(data);
        break;
      case "egzersiz":
        result = analyzeEgzersiz(data);
        break;
      case "sporlar":
        result = analyzeSporlar(data);
        break;
      case "uyku":
        result = analyzeUyku(data);
        break;
      default:
        result = "Bu kategoriye özel analiz bulunmuyor.";
        break;
    }

    setAnalizSonucu(result);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <Baslik />
        <TextInput
          style={styles.input}
          placeholder="Beslenme"
          onChangeText={(text) => setBeslenme(text)}
          value={beslenme}
        />
        <Button title="Beslenme Ekle" onPress={handleBeslenmeEkle} style={styles.button} />

        <TextInput
          style={styles.input}
          placeholder="Egzersizler"
          onChangeText={(text) => setEgzersiz(text)}
          value={egzersizler}
        />
        <Button title="Egzersiz Ekle" onPress={handleEgzersizEkle} style={styles.button} />

        <TextInput
          style={styles.input}
          placeholder="Sporlar"
          onChangeText={(text) => setSporlar(text)}
          value={sporlar}
        />
        <Button title="Spor Ekle" onPress={handleSporEkle} style={styles.button} />

        <TextInput
          style={styles.input}
          placeholder="Uykular"
          onChangeText={(text) => setUykular(text)}
          value={uyumalar}
        />
        <Button title="Uyku Ekle" onPress={handleUykuEkle} style={styles.button} />

        <Button title="Beslenme Analiz Et" onPress={() => handleAnalizEkle("beslenme")} />
        <Button title="Egzersiz Analiz Et" onPress={() => handleAnalizEkle("egzersiz")} />
        <Button title="Sporlar Analiz Et" onPress={() => handleAnalizEkle("sporlar")} />
        <Button title="Uyku Analiz Et" onPress={() => handleAnalizEkle("uyku")} />

        {data.map((item) => (
          <Text key={item.zaman}>{JSON.stringify(item)}</Text>
        ))}

        <Text>{analizSonucu}</Text>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  input: {
    height: 40,
    borderColor: "gray",
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  button: {
    marginTop: 10,
  },
});

export default App;




